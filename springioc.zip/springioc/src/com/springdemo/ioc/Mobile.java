package com.springdemo.ioc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Mobile {
	
	public static void main(String[] args) {
		
		ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
		System.out.println("Config Loaded successfully...!!");
		
		/*Airtel air=(Airtel)context.getBean("airtel");
		air.calling();
		air.data();
		
		Vodafone vodafone=context.getBean("vodafone",Vodafone.class);
		vodafone.calling();
		vodafone.data();*/
		
		Sim sim=context.getBean("sim", Sim.class);
		sim.calling();
		sim.data();
		
	}

}
