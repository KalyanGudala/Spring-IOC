package com.springdemo.ioc;

public interface Sim {
	
	void calling();
	void data();

}
